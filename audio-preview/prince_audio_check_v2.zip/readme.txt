Mac：双击 ZIP 解压，选中 MP3 后按空格试听。
A.mp3、B.mp3：用途待确认的短音效。
success_end.mp3：原包成功结束语候选。
end_1_timeout.mp3：时间用完了……
end_2_replay.mp3：点点奇奇再玩一次吧。
这些文件均取自本书原包。
